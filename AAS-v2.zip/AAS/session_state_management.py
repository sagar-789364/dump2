import streamlit as st
from datetime import datetime
from typing import Dict, Any, Optional

class SessionStateManager:
    """Centralized session state management for the application"""
    
    @staticmethod
    def initialize_base_state():
        """Initialize base application session state variables"""
        base_state_variables = {
            "logged_in": False,
            "username": "",
            "selected_service": None,
            "page_reload_counter": 0,
            "last_interaction": None,
            "form_submitted": False,
            "current_page": None,
            "sidebar_state": "collapsed",
            "page_history": [],
            "sidebar_disabled": False,
            "login_time": None,
            "all_sessions": []
        }
        
        for var, default_value in base_state_variables.items():
            if var not in st.session_state:
                st.session_state[var] = default_value
    
    @staticmethod
    def initialize_login_state():
        """Initialize login-related session state variables"""
        login_state_variables = {
            "login_btn_clicked": False,
            "username_input": "",
            "login_error": None,
            "greeting_loaded": False,
            "greeting_text": ""
        }
        
        for var, default_value in login_state_variables.items():
            if var not in st.session_state:
                st.session_state[var] = default_value
    
    @staticmethod
    def initialize_service_selection_state():
        """Initialize service selection related session state variables"""
        service_state_variables = {
            "research_btn_clicked": False,
            "memo_btn_clicked": False,
            "switch_service_btn_clicked": False,
            "logout_btn_clicked": False,
            "service_content_loaded": False,
            "service_content": None
        }
        
        for var, default_value in service_state_variables.items():
            if var not in st.session_state:
                st.session_state[var] = default_value
    
    @staticmethod
    def initialize_research_state():
        """Initialize research page related session state variables"""
        research_state_variables = {
            "chat_input_submitted": False,
            "chat_messages": [],
            "current_session_id": None,
            "sessions_loaded": False,
            "new_session_btn_clicked": False,
            "delete_session_btn_clicked": None,
            "session_to_delete": None,
            "search_results": None,
            "search_query": "",
            "ai_response": None,
            "processing_query": False
        }
        
        for var, default_value in research_state_variables.items():
            if var not in st.session_state:
                st.session_state[var] = default_value
    
    @staticmethod
    def initialize_memo_state():
        """Initialize memo generation related session state variables"""
        memo_state_variables = {
            "memo_form_submitted": False,
            "memo_content": "",
            "memo_generated": False,
            "memo_inputs": {},
            "memo_generation_in_progress": False,
            "memo_error": None
        }
        
        for var, default_value in memo_state_variables.items():
            if var not in st.session_state:
                st.session_state[var] = default_value
    
    @staticmethod
    def initialize_header_state():
        """Initialize header related session state variables"""
        header_state_variables = {
            "back_btn_clicked": False,
            "header_logo_loaded": False,
            "header_css_loaded": False
        }
        
        for var, default_value in header_state_variables.items():
            if var not in st.session_state:
                st.session_state[var] = default_value
    
    @staticmethod
    def reset_button_states():
        """Reset all button click states to prevent unwanted reruns"""
        button_states = [
            "login_btn_clicked",
            "research_btn_clicked", 
            "memo_btn_clicked",
            "switch_service_btn_clicked",
            "logout_btn_clicked",
            "new_session_btn_clicked",
            "delete_session_btn_clicked",
            "chat_input_submitted",
            "memo_form_submitted",
            "back_btn_clicked"
        ]
        
        for state in button_states:
            if state in st.session_state:
                st.session_state[state] = False
    
    @staticmethod
    def get_state_value(key: str, default: Any = None) -> Any:
        """Safely get a session state value"""
        return st.session_state.get(key, default)
    
    @staticmethod
    def set_state_value(key: str, value: Any):
        """Safely set a session state value"""
        st.session_state[key] = value
    
    @staticmethod
    def update_page_history(page_name: str):
        """Update page history without duplicates"""
        if "page_history" not in st.session_state:
            st.session_state.page_history = []
        
        if not st.session_state.page_history or st.session_state.page_history[-1] != page_name:
            st.session_state.page_history.append(page_name)
    
    @staticmethod
    def handle_logout():
        """Handle logout and reset relevant session state"""
        # Keep username and login time for potential re-login
        username = st.session_state.get("username", "")
        login_time = st.session_state.get("login_time", None)
        
        # Reset application state
        st.session_state.logged_in = False
        st.session_state.selected_service = None
        st.session_state.current_page = "login"
        st.session_state.page_history = []
        st.session_state.sidebar_disabled = True
        
        # Reset button states
        SessionStateManager.reset_button_states()
        
        # Clear service-specific data
        if "chat_messages" in st.session_state:
            st.session_state.chat_messages = []
        if "current_session_id" in st.session_state:
            st.session_state.current_session_id = None
        if "memo_content" in st.session_state:
            st.session_state.memo_content = ""
        
        # Preserve user info for convenience
        st.session_state.username = username
        st.session_state.login_time = login_time
    
    @staticmethod
    def handle_service_switch(new_service: str):
        """Handle switching between services"""
        if new_service in ["research", "memo"]:
            st.session_state.selected_service = new_service
            st.session_state.current_page = new_service
            SessionStateManager.update_page_history(new_service)
    
    @staticmethod
    def is_button_clicked(button_key: str) -> bool:
        """Check if a button was clicked and reset its state"""
        clicked = st.session_state.get(button_key, False)
        if clicked:
            st.session_state[button_key] = False
        return clicked
    
    @staticmethod
    def get_greeting() -> str:
        """Get time-appropriate greeting"""
        if not st.session_state.get("greeting_loaded", False):
            hour = datetime.now().hour
            if 5 <= hour < 12:
                greeting = "Good Morning"
            elif 12 <= hour < 17:
                greeting = "Good Afternoon"
            else:
                greeting = "Good Evening"
            
            st.session_state["greeting_text"] = greeting
            st.session_state["greeting_loaded"] = True
        
        return st.session_state.get("greeting_text", "Good Evening")
    
    @staticmethod
    def initialize_all_states():
        """Initialize all session states at once"""
        SessionStateManager.initialize_base_state()
        SessionStateManager.initialize_login_state()
        SessionStateManager.initialize_service_selection_state()
        SessionStateManager.initialize_research_state()
        SessionStateManager.initialize_memo_state()
        SessionStateManager.initialize_header_state()

# Convenience functions for common operations
def get_session_value(key: str, default: Any = None) -> Any:
    """Convenience function to get session state value"""
    return SessionStateManager.get_state_value(key, default)

def set_session_value(key: str, value: Any):
    """Convenience function to set session state value"""
    SessionStateManager.set_state_value(key, value)

def is_logged_in() -> bool:
    """Check if user is logged in"""
    return SessionStateManager.get_state_value("logged_in", False)

def get_current_user() -> str:
    """Get current username"""
    return SessionStateManager.get_state_value("username", "")

def get_selected_service() -> Optional[str]:
    """Get currently selected service"""
    return SessionStateManager.get_state_value("selected_service", None)