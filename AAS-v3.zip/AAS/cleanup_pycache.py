import shutil
import os

pycache_path = r"C:\Users\premmalothu\OneDrive - KPMG\Desktop\AAS\pages\Usecase_1\__pycache__"

try:
    if os.path.exists(pycache_path):
        shutil.rmtree(pycache_path)
        print(f"Deleted: {pycache_path}")
    else:
        print(f"No __pycache__ directory found at {pycache_path}")
except PermissionError:
    print(f"Permission denied: Could not delete {pycache_path}. Please close any programs using this directory and try again.")
