import os
import shutil
import stat

pycache_path = r"C:\Users\premmalothu\OneDrive - KPMG\Desktop\AAS\pages\Usecase_1\__pycache__"

def on_rm_error(func, path, exc_info):
    # Change the file to be writable and try again
    os.chmod(path, stat.S_IWRITE)
    func(path)

if os.path.exists(pycache_path):
    try:
        shutil.rmtree(pycache_path, onerror=on_rm_error)
        print(f"Deleted: {pycache_path}")
    except PermissionError:
        print(f"Permission denied: Could not delete {pycache_path}. Try running this script as administrator.")
else:
    print(f"No __pycache__ directory found at {pycache_path}")
