import streamlit as st
from streamlit_option_menu import option_menu
import streamlit.components.v1 as components

def initialize_session_state():
    """Initialize session state variables"""
    if 'current_page' not in st.session_state:
        st.session_state.current_page = 'new_chat'
    if 'chat_history' not in st.session_state:
        st.session_state.chat_history = []
    if 'recent_chats' not in st.session_state:
        st.session_state.recent_chats = [
            "Untitled",
            "Login Page UI Redesign", 
            "PDF and DOCX Generation Optimization",
            "PDF Preview UI Implementation",
            "Semantic Kernel Presentation Generator",
            "PowerPoint Text Frame Height Issues",
            "Slide Layout Optimization Algorithm",
            "Python Text Bullet Point Formatting",
            "Dynamic Row Height Cell Sizing"
        ]

def load_advanced_css():
    """Load advanced CSS for better Claude-style appearance"""
    st.markdown("""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    
    .stApp {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    }
    
    /* Sidebar styling */
    .css-1d391kg, .css-1cypcdb {
        background-color: #fafafa;
        border-right: 1px solid #e5e7eb;
    }
    
    /* Custom sidebar container */
    .claude-sidebar {
        padding: 0;
        height: 100vh;
        display: flex;
        flex-direction: column;
    }
    
    .sidebar-header {
        padding: 24px 20px;
        border-bottom: 1px solid #e5e7eb;
    }
    
    .sidebar-title {
        font-size: 28px;
        font-weight: 700;
        color: #111827;
        margin: 0;
        font-family: 'Inter', sans-serif;
    }
    
    .sidebar-nav-section {
        flex: 1;
        padding: 16px 0;
        overflow-y: auto;
    }
    
    .nav-button {
        display: flex;
        align-items: center;
        width: 100%;
        padding: 12px 20px;
        margin: 2px 8px;
        background: none;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.2s ease;
        color: #374151;
        font-size: 15px;
        font-weight: 500;
        text-decoration: none;
        font-family: 'Inter', sans-serif;
    }
    
    .nav-button:hover {
        background-color: #f3f4f6;
        color: #111827;
    }
    
    .nav-button.active {
        background-color: #dc2626;
        color: white;
    }
    
    .nav-button.new-chat {
        background-color: #dc2626;
        color: white;
        margin: 8px;
        font-weight: 600;
    }
    
    .nav-button.new-chat:hover {
        background-color: #b91c1c;
    }
    
    .nav-icon {
        width: 20px;
        height: 20px;
        margin-right: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 16px;
    }
    
    .section-divider {
        height: 1px;
        background-color: #e5e7eb;
        margin: 16px 20px;
    }
    
    .section-title {
        padding: 16px 20px 8px 20px;
        font-size: 13px;
        font-weight: 600;
        color: #6b7280;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        font-family: 'Inter', sans-serif;
    }
    
    .recent-chat-item {
        padding: 8px 20px;
        margin: 1px 8px;
        border-radius: 6px;
        cursor: pointer;
        transition: background-color 0.2s ease;
        font-size: 14px;
        color: #4b5563;
        font-family: 'Inter', sans-serif;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    
    .recent-chat-item:hover {
        background-color: #f9fafb;
        color: #111827;
    }
    
    .sidebar-footer {
        padding: 16px 20px;
        border-top: 1px solid #e5e7eb;
        background-color: #f9fafb;
    }
    
    .user-profile {
        display: flex;
        align-items: center;
        cursor: pointer;
        padding: 8px;
        border-radius: 8px;
        transition: background-color 0.2s ease;
    }
    
    .user-profile:hover {
        background-color: #f3f4f6;
    }
    
    .user-avatar {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        margin-right: 12px;
        font-weight: 600;
        color: white;
        font-size: 14px;
        font-family: 'Inter', sans-serif;
    }
    
    .user-info {
        flex: 1;
    }
    
    .user-name {
        font-weight: 600;
        color: #111827;
        font-size: 14px;
        margin: 0;
        font-family: 'Inter', sans-serif;
    }
    
    .user-plan {
        font-size: 12px;
        color: #6b7280;
        margin: 0;
        font-family: 'Inter', sans-serif;
    }
    
    /* Main content area */
    .main-content {
        padding: 24px;
        max-width: 800px;
        margin: 0 auto;
    }
    
    /* Hide Streamlit default elements */
    .stButton > button {
        display: none;
    }
    
    /* Custom scrollbar */
    .sidebar-nav-section::-webkit-scrollbar {
        width: 4px;
    }
    
    .sidebar-nav-section::-webkit-scrollbar-track {
        background: transparent;
    }
    
    .sidebar-nav-section::-webkit-scrollbar-thumb {
        background: #d1d5db;
        border-radius: 2px;
    }
    
    .sidebar-nav-section::-webkit-scrollbar-thumb:hover {
        background: #9ca3af;
    }
    </style>
    """, unsafe_allow_html=True)

def create_custom_sidebar():
    """Create the custom Claude-style sidebar"""
    with st.sidebar:
        st.markdown("""
        <div class="claude-sidebar">
            <div class="sidebar-header">
                <h1 class="sidebar-title">Claude</h1>
            </div>
            
            <div class="sidebar-nav-section">
                <div class="nav-button new-chat" onclick="handleNavClick('new_chat')">
                    <span class="nav-icon">➕</span>
                    New chat
                </div>
                
                <div class="section-divider"></div>
                
                <div class="nav-button" onclick="handleNavClick('chats')">
                    <span class="nav-icon">💬</span>
                    Chats
                </div>
                
                <div class="nav-button" onclick="handleNavClick('artifacts')">
                    <span class="nav-icon">🧩</span>
                    Artifacts
                </div>
                
                <div class="section-title">Recents</div>
        """, unsafe_allow_html=True)
        
        # Add recent chat items
        for i, chat in enumerate(st.session_state.recent_chats):
            st.markdown(f"""
                <div class="recent-chat-item" onclick="handleChatClick('{chat}')">
                    {chat}
                </div>
            """, unsafe_allow_html=True)
        
        st.markdown("""
            </div>
            
            <div class="sidebar-footer">
                <div class="user-profile">
                    <div class="user-avatar">P</div>
                    <div class="user-info">
                        <div class="user-name">Prem</div>
                        <div class="user-plan">Free plan</div>
                    </div>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)
        
        # JavaScript for handling clicks
        components.html("""
        <script>
        function handleNavClick(page) {
            // This would typically send data back to Streamlit
            console.log('Navigation clicked:', page);
        }
        
        function handleChatClick(chatName) {
            console.log('Chat clicked:', chatName);
        }
        </script>
        """, height=0)

def render_main_content():
    """Render the main content based on current page"""
    if st.session_state.current_page == 'new_chat':
        st.title("New Chat")
        st.markdown("Start a new conversation with Claude")
        
        # Chat interface
        user_input = st.text_input("Type your message here...")
        if st.button("Send") and user_input:
            st.session_state.chat_history.append({"user": user_input})
            # Add AI response logic here
            st.session_state.chat_history.append({"assistant": f"Response to: {user_input}"})
            st.rerun()
        
        # Display chat history
        for message in st.session_state.chat_history:
            if "user" in message:
                st.markdown(f"**You:** {message['user']}")
            else:
                st.markdown(f"**Claude:** {message['assistant']}")
                
    elif st.session_state.current_page == 'chats':
        st.title("Chat History")
        st.markdown("Browse your previous conversations")
        
        for chat in st.session_state.recent_chats:
            if st.button(chat, key=f"chat_hist_{chat}"):
                st.session_state.current_page = 'new_chat'
                st.rerun()
                
    elif st.session_state.current_page == 'artifacts':
        st.title("Artifacts")
        st.markdown("View and manage your created artifacts")
        
        st.info("No artifacts created yet. Start a conversation to generate some!")

def main():
    """Main application function"""
    st.set_page_config(
        page_title="Claude Style Streamlit App",
        page_icon="🤖",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    # Initialize session state
    initialize_session_state()
    
    # Load CSS
    load_advanced_css()
    
    # Create sidebar
    create_custom_sidebar()
    
    # Create navigation buttons (hidden but functional)
    col1, col2, col3 = st.columns(3)
    with col1:
        if st.button("New Chat", key="nav_new_chat"):
            st.session_state.current_page = 'new_chat'
            st.rerun()
    with col2:
        if st.button("Chats", key="nav_chats"):
            st.session_state.current_page = 'chats'
            st.rerun()
    with col3:
        if st.button("Artifacts", key="nav_artifacts"):
            st.session_state.current_page = 'artifacts'
            st.rerun()
    
    # Render main content
    with st.container():
        st.markdown('<div class="main-content">', unsafe_allow_html=True)
        render_main_content()
        st.markdown('</div>', unsafe_allow_html=True)

if __name__ == "__main__":
    main()